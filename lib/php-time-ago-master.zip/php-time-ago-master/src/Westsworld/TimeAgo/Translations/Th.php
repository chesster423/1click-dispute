<?php

namespace Westsworld\TimeAgo\Translations;

use \Westsworld\TimeAgo\Language;

/**
 * Thai translations
 */
class Th extends Language
{
    public function __construct()
    {
        $this->setTranslations([
            'aboutOneDay' => "1 วันที่แล้ว",
            'aboutOneHour' => "ประมาณ 1 ชั่วโมงที่แล้ว",
            'aboutOneMonth' => "ประมาณ 1 เดือนที่แล้ว",
            'aboutOneYear' => "ประมาณ 1 ปีที่แล้ว",
            'days' => "%s วันที่แล้ว",
            'hours' => "%s ชั่วโมงที่แล้ว",
            'lessThanAMinute' => "ไม่กี่นาทีที่แล้ว",
            'lessThanOneHour' => "%s นาทีที่แล้ว",
            'months' => "%s เดือนที่แล้ว",
            'oneMinute' => "1 นาทีที่แล้ว",
            'years' => "เกิน %s ปีแล้ว",
            'never' => 'ไม่มีข้อมูล'
        ]);
    }
}
