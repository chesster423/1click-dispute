<?php

namespace Westsworld\TimeAgo\Translations;

use \Westsworld\TimeAgo\Language;

/**
 * Korean translations
 */
class Ko extends Language
{
    public function __construct()
    {
        $this->setTranslations([
            'aboutOneDay' => "하루 전",
            'aboutOneHour' => "한 시간 전",
            'aboutOneMonth' => "한 달 전",
            'aboutOneYear' => "1년 전",
            'days' => "%s일 전",
            'hours' => "%s시간 전",
            'lessThanAMinute' => "방금",
            'lessThanOneHour' => "%s분 전",
            'months' => "%s달 전",
            'oneMinute' => "1분 전",
            'years' => "%s년 전"
        ]);
    }
}
