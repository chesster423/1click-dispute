<?php

namespace Westsworld\TimeAgo\Translations;

use \Westsworld\TimeAgo\Language;

/**
 * Dutch translations
 */
class Nl extends Language
{
    public function __construct()
    {
        $this->setTranslations([
            'aboutOneDay' => "1 dag geleden",
            'aboutOneHour' => "ongeveer 1 uur geleden",
            'aboutOneMonth' => "ongeveer 1 maand geleden",
            'aboutOneYear' => "ongeveer 1 jaar geleden",
            'days' => "%s dagen geleden",
            'hours' => "%s uur geleden",
            'lessThanAMinute' => "minder dan een minuut geleden",
            'lessThanOneHour' => "%s minuten geleden",
            'months' => "%s maanden geleden",
            'oneMinute' => "1 minuut geleden",
            'years' => "meer dan %s jaar geleden"
        ]);
    }
}
