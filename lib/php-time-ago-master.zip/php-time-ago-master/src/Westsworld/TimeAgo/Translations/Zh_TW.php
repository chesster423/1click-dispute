<?php

namespace Westsworld\TimeAgo\Translations;

use \Westsworld\TimeAgo\Language;

/**
 * Translations
 */
class Zh_Tw extends Language
{
    public function __construct()
    {
        $this->setTranslations([
            'aboutOneDay' => "1天前",
            'aboutOneHour' => "大約1小時前",
            'aboutOneMonth' => "大約1個月前",
            'aboutOneYear' => "大約1年前",
            'days' => "%s天前",
            'hours' => "%s小時前",
            'lessThanAMinute' => "1分鐘內",
            'lessThanOneHour' => "%s分鐘前",
            'months' => "%s個月前",
            'oneMinute' => "1分鐘前",
            'years' => "超過%s年前"
        ]);
    }
}
