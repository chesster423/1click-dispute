<?php

namespace Westsworld\TimeAgo\Translations;

use \Westsworld\TimeAgo\Language;

/**
 * Translations
 */
class Ja extends Language
{
    public function __construct()
    {
        $this->setTranslations([
            'aboutOneDay' => "1日前",
            'aboutOneHour' => "約1時間前",
            'aboutOneMonth' => "約1ヶ月前",
            'aboutOneYear' => "約1年前",
            'days' => "%s日前",
            'hours' => "%s時間前",
            'lessThanAMinute' => "たった今",
            'lessThanOneHour' => "%s分前",
            'months' => "%sヶ月前",
            'oneMinute' => "1分前",
            'years' => "%s年以上前"
        ]);
    }
}
