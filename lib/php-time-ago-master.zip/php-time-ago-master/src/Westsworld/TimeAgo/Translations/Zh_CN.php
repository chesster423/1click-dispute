<?php

namespace Westsworld\TimeAgo\Translations;

use \Westsworld\TimeAgo\Language;

/**
 * Chinese translations
 */
class Zh_CN extends Language
{
    public function __construct()
    {
        $this->setTranslations([
            'aboutOneDay' => "1 天前",
            'aboutOneHour' => "大约 1 小时前",
            'aboutOneMonth' => "大约 1 个月前",
            'aboutOneYear' => "大约 1 年前",
            'days' => "%s 天前",
            'hours' => "%s 小时前",
            'lessThanAMinute' => "1 分钟内",
            'lessThanOneHour' => "%s 分钟前",
            'months' => "%s 个月前",
            'oneMinute' => "1 分钟前",
            'years' => "超过 %s 年前"
        ]);
    }
}
